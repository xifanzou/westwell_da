from ..IGV.icave_processer import adhoc_process, correct_block
from modules.map import get_map_config